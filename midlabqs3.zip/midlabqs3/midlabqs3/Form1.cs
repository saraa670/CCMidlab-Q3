using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace midlabqs3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string command = txtCommand.Text.Trim();
            
            lblResult.Text = IsValidCommand(command) ? "Valid Command" : "Invalid Command";
        }

        private bool IsValidCommand(string command)
        {
           
            string initialState = "S0";
            string currentState = initialState;

            
            var transitions = new Dictionary<string, Dictionary<string, string>>
            {
                { "S0", new Dictionary<string, string>
                    {
                        { "Start", "S1" },
                        { "Stop", "S1" },
                        { "Accelerate", "S1" },
                        { "Brake", "S1" },
                        { "Right", "S1" }
                    }
                },
                { "S1", new Dictionary<string, string>
                    {
                        { "Start", "S1" },
                        { "Stop", "S1" },
                        { "Accelerate", "S1" },
                        { "Brake", "S1" },
                        { "Right", "S1" }
                    }
                }
            };

            
            string[] commands = command.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            
            foreach (string cmd in commands)
            {
                
                if (transitions[currentState].ContainsKey(cmd))
                {
                    
                    currentState = transitions[currentState][cmd];
                }
                else
                {
                    
                    return false;
                }
            }

           
            return currentState == "S1";
        }

        private void lblResult_Click(object sender, EventArgs e)
        {
           
        }

        private void txtCommand_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }
    }
}
