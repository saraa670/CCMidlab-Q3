﻿namespace midlabqs3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtCommand = new TextBox();
            button1 = new Button();
            lblResult = new Label();
            SuspendLayout();
            // 
            // txtCommand
            // 
            txtCommand.BorderStyle = BorderStyle.FixedSingle;
            txtCommand.Location = new Point(262, 75);
            txtCommand.Name = "txtCommand";
            txtCommand.Size = new Size(145, 23);
            txtCommand.TabIndex = 0;
            txtCommand.TextChanged += txtCommand_TextChanged;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(297, 125);
            button1.Name = "button1";
            button1.Size = new Size(85, 29);
            button1.TabIndex = 1;
            button1.Text = "Check Command";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            lblResult.Location = new Point(382, 194);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(0, 15);
            lblResult.TabIndex = 2;
            lblResult.Click += lblResult_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.MidnightBlue;
            ClientSize = new Size(650, 339);
            Controls.Add(lblResult);
            Controls.Add(button1);
            Controls.Add(txtCommand);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtCommand;
        private Button button1;
        private Label lblResult;
    }
}
